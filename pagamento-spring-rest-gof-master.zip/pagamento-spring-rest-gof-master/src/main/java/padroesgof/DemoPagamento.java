package padroesgof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoPagamento {

	public static void main(String[] args) {
		SpringApplication.run(DemoPagamento.class, args);
	}

}
