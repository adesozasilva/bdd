Exemplo de teste de integração usando BDD

Caso a solução esteja rodando em localhost / máquina local:

1) git clone

2) mvn test

Caso a solução esteja rodando em outra URL, deve-se ajustar a variável URL em StepDefs.
